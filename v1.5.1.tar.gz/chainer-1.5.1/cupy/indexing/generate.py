# flake8: NOQA
# "flake8: NOQA" to suppress warning "H104  File contains nothing but comments"


# class c_(object):
# class r_(object):
# class s_(object):


# TODO(okuta): Implement indices


# TODO(okuta): Implement ix_


# TODO(okuta): Implement ravel_multi_index


# TODO(okuta): Implement unravel_index


# TODO(okuta): Implement diag_indices


# TODO(okuta): Implement diag_indices_from


# TODO(okuta): Implement mask_indices


# TODO(okuta): Implement tril_indices


# TODO(okuta): Implement tril_indices_from


# TODO(okuta): Implement triu_indices


# TODO(okuta): Implement triu_indices_from
