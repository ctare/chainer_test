from cupy import core


# TODO(okuta): Implement allclose


# TODO(okuta): Implement isclose


# TODO(okuta): Implement array_equal


# TODO(okuta): Implement array_equiv


greater = core.greater


greater_equal = core.greater_equal


less = core.less


less_equal = core.less_equal


equal = core.equal


not_equal = core.not_equal
