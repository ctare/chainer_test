Indexing Routines
=================

.. autofunction:: cupy.take
.. autofunction:: cupy.diagonal
