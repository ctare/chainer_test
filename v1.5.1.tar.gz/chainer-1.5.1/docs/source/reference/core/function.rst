Function
--------

.. currentmodule:: chainer
.. autoclass:: Function
   :members:
