Optimizer
---------

.. currentmodule:: chainer
.. autoclass:: Optimizer
   :members:
.. autoclass:: GradientMethod
   :members:

Hook functions
~~~~~~~~~~~~~~
.. autoclass:: chainer.optimizer.WeightDecay
.. autoclass:: chainer.optimizer.GradientClipping
