.. module:: chainer.serializers

Serializers
===========

Serialization in HDF5 format
----------------------------
.. autoclass:: HDF5Serializer
.. autoclass:: HDF5Deserializer
.. autofunction:: save_hdf5
.. autofunction:: load_hdf5
