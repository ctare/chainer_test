--------------------
Core functionalities
--------------------

.. currentmodule:: chainer
.. toctree::
   :maxdepth: 1

   core/variable
   core/flag
   core/function
   core/link
   core/optimizer
   core/serializer
   core/function_set
